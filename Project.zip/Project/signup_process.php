<?php
// Include the database connection
include 'db_connect.php';

// Get user input from the form
$name = $_POST['signupName'];
$address = $_POST['signupAddress'];
$tel = $_POST['signupTel'];
$vehicleNo = $_POST['signupVehicleNo'];
$email = $_POST['signupEmail'];
$username = $_POST['signupUsername'];
$password = $_POST['signupPassword'];
$accessLevel = $_POST['signupAccessLevel'];

// Basic validation (you can enhance this as needed)
if (empty($name) || empty($address) || empty($tel) || empty($vehicleNo) || empty($email) || empty($username) || empty($password)) {
    echo "All fields are required.";
} else {
   
   $hashedPassword = ($password);

    // Prepare and execute the SQL statement
    $sql = "INSERT INTO us_acc (name, address, tel, vehicle_no, email, username, password, access_level)
            VALUES ('$name', '$address', '$tel', '$vehicleNo', '$email', '$username', '$hashedPassword', '$accessLevel')";

    if ($conn->query($sql) === TRUE) {
        echo "User registered successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
