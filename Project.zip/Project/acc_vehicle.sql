-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 13, 2023 at 03:48 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `acc_vehicle`
--

-- --------------------------------------------------------

--
-- Table structure for table `us_acc`
--

CREATE TABLE IF NOT EXISTS `us_acc` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `vehicle_no` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `access_level` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `us_acc`
--

INSERT INTO `us_acc` (`id`, `name`, `address`, `tel`, `vehicle_no`, `email`, `username`, `password`, `access_level`) VALUES
(1, 'sdfsdf', 'sdfsdfsd', '234234', '24234', 'wwerwer@gmail.com', '343', '77963b7a931377ad4ab5ad6a9cd718', 'user'),
(2, 'sdfsdfsd', 'sdfsdf', '34234', 'sdfsdf', 'sfddfsdfsd@gmail.com', '555', '9df62e693988eb4e1e1444ece05785', 'user'),
(3, 'sfdgfdg', 'dfgd', 'fgdfg', 'dfgdfg', 'sfddfsdfsd@gmail.com', '3333', '3333', 'user');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
