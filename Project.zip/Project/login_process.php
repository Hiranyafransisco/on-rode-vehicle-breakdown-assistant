<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

include 'db_connect.php'; // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Retrieve user info from the database
    $stmt = $conn->prepare("SELECT * FROM us_acc WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // Verify the password using MD5 (not secure)
        if (md5($password) === $user['password']) {
            $_SESSION['username'] = $username;
            $_SESSION['access_level'] = $user['access_level'];

            // Redirect based on access level
            if ($user['access_level'] === 'user') {
                header("Location: users.php");
            } elseif ($user['access_level'] === 'mechani') {
                header("Location: mechani.php");
            } elseif ($user['access_level'] === 'admin') {
                header("Location: admin.php");
            } else {
                $loginError = "Invalid access level.";
            }
        } else {
            $loginError = "Invalid password.";
        }
    } else {
        $loginError = "Username not found.";
    }
    $stmt->close();
}

$conn->close(); // Close the database connection
?>
